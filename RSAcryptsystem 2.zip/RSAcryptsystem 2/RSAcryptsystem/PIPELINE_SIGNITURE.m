%run setup
b = 14; %number of bits that we are working in
[publickey,secretkey]=setup(b);
%send 
filename = 'trialsig1.txt';
message = 'MAT';
RSAencrypt_sig(message,publickey,filename);
%read
msg = RSAdecrypt_sig(secretkey,filename)

