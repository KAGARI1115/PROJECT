function [d,x,y]=EUCLID(a,b) % find d,x,y s.t. d = gcd(a,b) = xa+yb
if b==0
    d = a;
    x=1;
    y=0;
    return
else
    [d0,x0,y0] = EUCLID(b, mod(a,b));
    d = d0;
    x = y0;
    y = x0-floor(a/b)*y0;
    return
end


