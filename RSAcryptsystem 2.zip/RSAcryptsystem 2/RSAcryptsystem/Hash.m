function h = Hash(k)
A = (sqrt(5)-1)/2;
m = 2^14;
h = floor(m*mod(k*A,1));

