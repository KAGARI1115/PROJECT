function [publickey,secretkey]=setup(b)
%b=set the number of bits of n
%pick two primes p,q, with both approximately b/2 bits
%set n = pq
%[p,q] = PICKPRIME_PT(b);
[p,q] = PICKPRIME_MRPT(b);
n = p*q;

%compute e s.t. gcd(e,phi(n))=1
%we simple find a prime number that is within max(p,q) and max(p,q)^3/2
mi = ceil(max(p,q)/2);
ma = floor(n/2);
primetestp = 0;
while primetestp==0
ptest = randi([mi,ma])*2+1;
% if MRPT(ptest)
    if PT(ptest)
        e = ptest;
        primetestp=1;
    end
end
%compute d s.t. ed=1 mod phi(n)
phi = (p-1)*(q-1);
d = MODULAR_LINEAR_EQUATION(e,phi);

%Assign keys
publickey = [e,n];
secretkey = [d,n];