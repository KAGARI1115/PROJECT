% pick 2 primes p,q s.t. pq>n
function [p,q]=PICKPRIME_PT(N)
l = ceil(N/2); % let length of p,q be l
min = 2^(l-1);
max = 2^l;
primetestp = 0;
while primetestp==0
ptest = randi([min,max])*2+1;
    if PT(ptest)
        p = ptest;
        primetestp=1;
    end
end
primetestq=0;
while primetestq==0
    qtest = randi([min,max])*2+1;
    if PT(qtest) & qtest~=p
        q = qtest;
        primetestq=1;
    end
end
