function prime=PT(n)
if n==1
    prime=false;
    return 
elseif n<=3
    prime = true;
    return 
elseif mod(n,2)==0 | mod(n,3)==0
    prime = false;
    return
end
i = 5;
while i^2<=n 
    if mod(n,i)==0 | mod(n,i+2)==0
        prime = false;
        return
    end
    i = i+6;
end
prime = true;
    