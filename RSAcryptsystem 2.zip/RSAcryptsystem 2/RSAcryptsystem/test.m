a = [1,222,3]
file=fopen('msg.txt','w');
fprintf(file,'%u\n',a);
fclose(file);

fileread =fopen('msg.txt','r');
A=fscanf(fileread,'%d')';
fclose(fileread);

%%
str = 'abcdd'
msgbi=[];
for i = 1:length(str)
    m = str(i)-0;
    m = de2bi(m,7);
    msgbi = [msgbi,m];
end

i = 1;
str='';
if mod(length(msgbi),7)~=0
    disp('message input error')
end
while i<length(msgbi)
    m = msgbi(i:i+6);
    m = bi2de(m);
    str = strcat(str,char(m));
    i = i + 7;
end
str

%%
a = [1,2,3];
length(a(4:end))

%%
word='thank you';
DIC = [];
%convert msg to binary
msgbi = [];
for i = 1:length(word)
    chr = word(i)-0;
    m = de2bi(chr,7);
    msgbi = [msgbi,m];
end
if mod(length(msgbi),7)~=0
    disp('input error')
    disp(word)
    return
end
%convert binary msgbi to numbers
i=1;
while i<length(msgbi)
    msg = msgbi(i:min(i+20,length(msgbi)));
    i = min(i+20,length(msgbi))+1;
    M = bi2de(msg);
    DIC = [DIC,M];
end
%read back from DIC
READ = DIC;
readbi=[];
for i=1:length(READ)-1
    send = READ(i);
    sendbi = de2bi(send,21);
    readbi = [readbi,sendbi];
end
sendbi = de2bi(READ(end));
readbi = [readbi,sendbi];
str=[];
for j = 1:length(readbi)/7
    index = 1+(j-1)*7;
    MSG = bi2de(readbi(index:index+6));
    ch = char(MSG);
    str = [str,ch];
end
str

%%
n = p*q
d = 111638353;
y=(p-1)*(q-1)
[a,b,c]=EUCLID(d,y)
%MODULAREXPO(72832349,e,n)
%%
b
mod(b*d,y)
e=mod(b,y)
e*d
mod(e*d,y)
%%
word0='abd'
publickey=[7,15];
filename='trialsig.txt'
%len = b-mod(b,7);
word=word0;
e = publickey(1);
n = publickey(2);
%convert msg to binary
msgbi = [];
for i = 1:length(word)
    word(i);
    chr = word(i)-0;
    m = de2bi(chr,7);
    msgbi = [msgbi,m];
end
if mod(length(msgbi),7)~=0
    disp('input error')
    disp(word)
    return
end
%convert binary msgbi to numbers

%i=1;
%while i<length(msgbi)
%    msg = msgbi(i:min(i+len-1,length(msgbi)));
%    i = min(i+len-1,length(msgbi))+1;
M = bi2de(msgbi)
H = Hash(M)
H = MODULAREXPO(H,e,n)
SEND = [M,H]

% store message
file=fopen(filename,'w');
fprintf(file,'%u\n',SEND);
fclose(file);
%%
a = [1,2,3];
a(4:end)
%%
Y = [];
for x = 0.001:0.001:0.45
    y = 0.5*log(1/(x*(1-x)))*(x*log(1/x)+(1-x)*log(1/(1-x)));
    y = sqrt(1/y);
    Y = [Y,y];
end
X = 0.001:0.001:0.45;
plot(X,Y)
    