function P=MRPT(n,s)
for i = 1:s
    a = randi(n-1);
    if MRPT_WITNESS(a,n)
        P = false;
        return 
    end
end
P = true;

