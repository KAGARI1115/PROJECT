function [str,SIG]=RSAdecrypt_sig(secretkey,filename)
%len = b-mod(b,7);
%specify key
d = secretkey(1);
n = secretkey(2);
%read message
fileread =fopen(filename,'r');
READ=fscanf(fileread,'%d')';
fclose(fileread);
%recover msg by key
msg = READ(1);
signature= MODULAREXPO(READ(2),d,n);
if signature ~= Hash(msg)
    SIG = false;
    disp('signature not matching')
    str=' ';
    return 
else
    SIG = true;
    disp('signature matching')
    msgbi = de2bi(msg);
    i = 1;
    str = '';
    while ~isempty(msgbi)
        wd = msgbi(1:min(7,length(msgbi)));
        ch = bi2de(wd);
        ch = char(ch);
        str = [str,ch];
        msgbi = msgbi(min(7,length(msgbi))+1:end);
    end
end
        
