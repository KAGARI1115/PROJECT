function d=MODULAR_LINEAR_EQUATION(e,n)%find d s.t. ed=1 mod n
[z,x,y] = EUCLID(e,n);
d = mod(x,n);
