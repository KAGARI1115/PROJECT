function d = MODULAREXPO(a,b,n) % compute a^b mod n
d = 1;
B = de2bi(b);
for i = length(B):-1:1
    d = mod(d^2,n);
    if B(i)==1
        d = mod(d*a,n);
    end
end
