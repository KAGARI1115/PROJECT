function str=RSAdecrypt(secretkey,b,filename)
len = b-mod(b,7);
%specify key
d = secretkey(1);
n = secretkey(2);
%read message
fileread =fopen(filename,'r');
READ=fscanf(fileread,'%d')';
fclose(fileread);
%recover msg by key
readbi=[];
for i=1:length(READ)-1
    send = READ(i);
    send = MODULAREXPO(send,d,n);
    sendbi = de2bi(send,len);
    readbi = [readbi,sendbi];
end
sendbi = MODULAREXPO(READ(end),d,n);
sendbi = de2bi(sendbi);
readbi = [readbi,sendbi];
str=[];

while ~isempty(readbi)
        wd = readbi(1:min(7,length(readbi)));
        ch = bi2de(wd);
        ch = char(ch);
        str = [str,ch];
        readbi = readbi(min(7,length(readbi))+1:end);
    end

