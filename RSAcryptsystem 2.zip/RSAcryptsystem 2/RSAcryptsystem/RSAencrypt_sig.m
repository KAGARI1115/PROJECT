function RSAencrypt_sig(word0,publickey,filename)
if length(word0)>3
    disp('message too long')
    return
end
%len = b-mod(b,7);
word=word0;
e = publickey(1);
n = publickey(2);
%convert msg to binary
msgbi = [];
for i = 1:length(word)
    word(i);
    chr = word(i)-0;
    m = de2bi(chr,7);
    msgbi = [msgbi,m];
end
if mod(length(msgbi),7)~=0
    disp('input error')
    disp(word)
    return
end
%convert binary msgbi to numbers

%i=1;
%while i<length(msgbi)
%    msg = msgbi(i:min(i+len-1,length(msgbi)));
%    i = min(i+len-1,length(msgbi))+1;
M = bi2de(msgbi);
H = Hash(M);
H = MODULAREXPO(H,e,n);
SEND = [M,H];

% store message
file=fopen(filename,'w');
fprintf(file,'%u\n',SEND);
fclose(file);