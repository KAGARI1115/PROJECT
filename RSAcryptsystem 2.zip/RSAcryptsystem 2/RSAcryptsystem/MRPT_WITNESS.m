function C=MRPT_WITNESS(a,n) %check if n is composite by witness a
% find u,t s.t. n = 2^t*u
N = de2bi(n-1);
if N(1)==1
    t=0;
    u=n-1;
else
    i=1;
    while N(i+1)==0
        i=i+1;
    end
    t=i;
    u = bi2de(N(i+1:end));
end
%
X = zeros(1,t+1);
X(1)=MODULAREXPO(a,u,n);
for i = 2:t+1
    X(i) = mod(X(i-1)^2,n);
    if X(i)==1 & X(i-1)~=1 & X(i-1)~=n-1
        C = true;
        return
    end
end
if X(end)~=1
    C = true;
    return
end
C=false;
return 