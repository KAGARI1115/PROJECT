% pick 2 primes p,q s.t. pq>n
function [p,q]=PICKPRIME_MRPT(N)
l = ceil(N/2); % let length of p,q be l
min = 2^(l-1);
max = 2^l;
primetestp = 0;
while primetestp==0
ptest = randi([min,max])*2+1;
    if MRPT(ptest,5)
        p = ptest;
        primetestp=1;
    end
end
primetestq=0;
while primetestq==0
    qtest = randi([min,max])*2+1;
    if MRPT(qtest,5) & qtest~=p
        q = qtest;
        primetestq=1;
    end
end


