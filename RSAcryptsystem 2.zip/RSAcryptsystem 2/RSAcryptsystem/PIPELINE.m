%run setup
b = 21; %number of bits that we are working in
[publickey,secretkey]=setup(b);

%send 
filename = 'trial1.txt';
message = 'MATH5653';
RSAencrypt(message,b,publickey,filename);
%read
msg = RSAdecrypt(secretkey,b,filename)



